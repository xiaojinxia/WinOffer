import test from 'node:test';
import assert from 'node:assert/strict';
import { createApplication, applyChange, info, hasPendingTask, standard, validateNode, validateBackup, validDate, validUrl, splitCities, advanceResumeScreening } from '../shared/model.js';

const basics={company:'示例公司',role:'后端开发',type:'私企',city:'合肥、南京'};
const fresh=()=>createApplication(basics,'application-1','2026-09-21T00:00:00.000Z');
const node=(r,key,status)=>applyChange(r,{type:'node',nodeId:`stage-${key}`,data:{status}});

test('待完成包含六个标准阶段的已安排状态，不要求填写日期',()=>{
  for(const key of [1,2,3,4,5,6]){
    const r=node(fresh(),key,'scheduled');
    assert.equal(hasPendingTask(r),true,info(r).title);
    for(const status of ['idle','active','waiting','passed','failed','skipped']){
      assert.equal(hasPendingTask(node(r,key,status)),false,`${r.nodes[key].name} ${status}`);
    }
  }
});

test('待完成不包含投递、Offer、自定义阶段及已结束的记录',()=>{
  for(const key of [0,7])assert.equal(hasPendingTask(node(fresh(),key,'scheduled')),false);
  const custom=fresh();custom.nodes.push({...custom.nodes[0],id:'custom',key:null,name:'自定义面试',status:'scheduled'});
  assert.equal(hasPendingTask(custom),false);
  const scheduled=node(fresh(),4,'scheduled');
  assert.equal(hasPendingTask(applyChange(scheduled,{type:'end',reason:'主动放弃'})),false);
  assert.equal(hasPendingTask(node(scheduled,3,'failed')),false);
  for(const decision of ['pending','accepted','declined']){
    assert.equal(hasPendingTask(applyChange(node(scheduled,7,'passed'),{type:'offer',decision})),false);
  }
});

test('待完成跟随当前阶段，旧节点遗留的已安排状态不会重复列为待办',()=>{
  const scheduled=node(fresh(),1,'scheduled');
  for(const status of ['active','waiting','passed'])assert.equal(hasPendingTask(node(scheduled,3,status)),false);
  assert.equal(hasPendingTask(node(scheduled,3,'scheduled')),true);
  const reordered=node(fresh(),1,'scheduled');
  const assessment=reordered.nodes.splice(1,1)[0];reordered.nodes.splice(5,0,assessment);
  assessment.name='在线测评';
  assert.equal(hasPendingTask(reordered),true);
});

test('面试完成待结果与已通过等待下一轮使用不同摘要，仅自动推进简历筛选',()=>{
  let r=node(fresh(),4,'waiting');
  assert.equal(info(r).title,'一面待结果');
  assert.equal(r.nodes[0].status,'passed');
  r=node(r,4,'passed');
  assert.equal(info(r).title,'一面已通过');
  assert.equal(info(r).detail,'等待二面安排');
  assert.equal(r.nodes[3].status,'idle');
});

test('后续各阶段有状态时简历自动通过，包含跳过与未通过，不修改其他节点或补填日期',()=>{
  for(const key of [1,2,3,4,5,6,7]){
    for(const status of ['scheduled','active','waiting','passed','failed','skipped']){
      const original=fresh(),result=node(original,key,status);
      assert.equal(result.nodes[0].status,'passed',`${key} ${status}`);
      assert.equal(result.nodes[0].completedDate,'');
      assert.equal(original.nodes[0].status,'waiting');
      for(const other of original.nodes.filter(n=>n.key!==0&&n.key!==key))assert.deepEqual(result.nodes.find(n=>n.id===other.id),other);
      assert.match(result.history.at(-1).text,/投递简历自动标记为已通过/);
      const again=node(result,key,status);assert.doesNotMatch(again.history.at(-1).text,/自动标记/);
    }
  }
});

test('未开始节点仅填写备注或时间不会推进简历，明确设置的简历结果保持不变',()=>{
  const r=applyChange(fresh(),{type:'node',nodeId:'stage-3',data:{date:'2026-09-25',notes:'准备材料'}});
  assert.equal(r.nodes[0].status,'waiting');
  for(const status of ['idle','scheduled','active','passed','failed','skipped']){
    const original=node(fresh(),0,status),result=node(original,3,'scheduled');
    assert.equal(result.nodes[0].status,status);
  }
});

test('自动筛选按实际流程支持自定义后续节点，流程撤销可恢复原来的待筛选状态',()=>{
  const r=fresh(),custom={...r.nodes[1],id:'custom',key:null,name:'沟通',status:'waiting'};
  const changed=applyChange(r,{type:'workflow',nodes:[...r.nodes,custom]});
  assert.equal(changed.nodes[0].status,'passed');assert.equal(changed.history.at(-1).type,'workflow');
  assert.deepEqual(applyChange(changed,{type:'undo-workflow'}).nodes,r.nodes);
  const beforeResume={...r,nodes:[custom,...r.nodes]};assert.equal(advanceResumeScreening(beforeResume),beforeResume);
  const noResume={...r,nodes:[custom]};assert.equal(advanceResumeScreening(noResume),noResume);
});
test('未通过结束投递，纠正结果恢复活动状态，不修改后续节点',()=>{
  let r=node(fresh(),4,'failed');
  assert.equal(info(r).kind,'ended');assert.equal(r.nodes[5].status,'idle');
  r=node(r,4,'waiting');assert.equal(info(r).kind,'active');
});
test('主动结束与节点拒绝相互独立，恢复不会把拒绝改成通过',()=>{
  let r=node(fresh(),4,'failed');
  r=applyChange(r,{type:'end',reason:'主动放弃'});assert.equal(info(r).title,'主动放弃');
  r=applyChange(r,{type:'resume'});assert.equal(info(r).title,'一面未通过');
});
test('跳过不算通过，摘要寻找下一个有效阶段',()=>{
  let r=node(fresh(),4,'passed');r=node(r,5,'skipped');
  assert.equal(info(r).detail,'等待三面安排');assert.equal(r.nodes[5].status,'skipped');
});
test('Offer 可以接受、婉拒和改回待定，纠正收到状态后清除决定',()=>{
  let r=node(fresh(),7,'passed');assert.equal(info(r).kind,'offer');
  r=applyChange(r,{type:'offer',decision:'accepted'});assert.equal(info(r).title,'已接受 Offer');
  r=applyChange(r,{type:'offer',decision:'declined'});assert.equal(info(r).kind,'ended');
  r=applyChange(r,{type:'offer',decision:'pending'});assert.equal(info(r).kind,'offer');
  r=node(r,7,'waiting');assert.equal(r.offerDecision,'pending');assert.equal(info(r).kind,'active');
});
test('调整流程保留删除前的状态和备注，可以完整撤销',()=>{
  let r=applyChange(fresh(),{type:'node',nodeId:'stage-4',data:{status:'passed',notes:'保留面试复盘',date:'2026-09-20'}});
  const before=structuredClone(r.nodes);
  r=applyChange(r,{type:'workflow',nodes:r.nodes.filter(n=>n.key!==4)});
  assert.equal(r.nodes.length,7);assert.equal(standard(r),true);
  r=applyChange(r,{type:'undo-workflow'});assert.deepEqual(r.nodes,before);
  assert.throws(()=>applyChange(r,{type:'undo-workflow'}),/最近一次/);
});
test('调整标准阶段先后或加入自定义节点时使用实际流程',()=>{
  const r=fresh();[r.nodes[2],r.nodes[3]]=[r.nodes[3],r.nodes[2]];assert.equal(standard(r),false);
  r.nodes.push({...r.nodes[0],id:'hr',key:null,name:'HR 面'});assert.equal(standard(r),false);
});
test('撤销移除 Offer 节点时也恢复此前的接受决定',()=>{
  let r=node(fresh(),7,'passed');r=applyChange(r,{type:'offer',decision:'accepted'});
  r=applyChange(r,{type:'workflow',nodes:r.nodes.filter(n=>n.key!==7)});
  assert.equal(r.offerDecision,'pending');
  r=applyChange(r,{type:'undo-workflow'});assert.equal(r.offerDecision,'accepted');assert.equal(info(r).title,'已接受 Offer');
});
test('日期精度与时间关系得到验证，非法日期不会漏到服务器错误',()=>{
  assert.equal(validDate(''),'');assert.equal(validDate('2024-02-29'),'2024-02-29');
  for(const d of ['2026-02-29','2026-13-01','2026-00-00','2026-04-31'])assert.throws(()=>validDate(d),/有效日期/);
  assert.throws(()=>validateNode({...fresh().nodes[0],time:'12:00'}),/安排日期/);
  assert.throws(()=>validateNode({...fresh().nodes[0],deadlineTime:'12:00'}),/截止日期/);
});
test('链接仅允许网页地址，多城市规范化且不丢失',()=>{
  assert.throws(()=>validUrl('javascript:alert(1)'),/http/);
  assert.throws(()=>validUrl('https://user:secret@example.com'),/http/);
  assert.equal(validUrl('https://example.com/jobs?id=1'),'https://example.com/jobs?id=1');
  assert.deepEqual(splitCities('合肥，南京、合肥; 上海'),['合肥','南京','上海']);
});
test('备份完整验证包含重复标识、节点状态、版本和历史',()=>{
  const backup={format:'winoffer-backup',version:1,exportedAt:'2026-09-21T00:00:00.000Z',records:[fresh()]};
  assert.deepEqual(validateBackup(backup),backup);
  assert.throws(()=>validateBackup({...backup,version:2}),/版本/);
  assert.throws(()=>validateBackup({...backup,records:[fresh(),fresh()]}),/重复/);
  const bad=structuredClone(backup);bad.records[0].nodes[0].status='unknown';assert.throws(()=>validateBackup(bad),/状态/);
});
test('岗位可以不填，未填写岗位的记录仍能编辑和备份恢复',()=>{
  const r=createApplication({company:'可选岗位公司',type:'私企'},'optional-role');
  assert.equal(r.role,'');
  const updated=applyChange(r,{type:'node',nodeId:'stage-4',data:{status:'waiting'}});
  const backup={format:'winoffer-backup',version:1,exportedAt:new Date().toISOString(),records:[updated]};
  assert.equal(validateBackup(backup).records[0].role,'');
});
test('岗位分类兼容大小写和空格，同时保留无法归类的历史岗位',()=>{
  assert.equal(createApplication({...basics,role:'ai应用'},'ai-role').role,'AI应用');
  assert.equal(createApplication({...basics,role:'JAVA 后端'},'java-role').role,'Java后端');
  const legacy=createApplication({...basics,role:'嵌入式软件工程师'},'legacy-role');
  assert.equal(applyChange(legacy,{type:'node',nodeId:'stage-4',data:{status:'passed'}}).role,'嵌入式软件工程师');
});
